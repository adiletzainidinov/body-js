let firstUserName = 'Bekbolsun'
let secondUserName = 'Bektur'
let thirdUserName = 'Alisher'
let fourthUserName = 'Elizar'
let firstUserPoint = 97
let secondUserPoint = 89
let thirdUserPoint = 75
let fourthUserPoint = 90

let resultOfBekbolsun = '1.' + firstUserName + '-' + firstUserPoint + ' ' + 'баллов из 100'
console.log(resultOfBekbolsun)

let resultOfNameAndPoint2 = '1.' + secondUserName + '-' + secondUserPoint + ' ' + 'баллов из 100'
console.log(resultOfNameAndPoint2)

let resultOfAlisher = '1.' + thirdUserName + '-' + thirdUserPoint + ' ' + 'баллов из 100'
console.log(resultOfAlisher)

let resultOfElizar = '1.' + fourthUserName + '-' + fourthUserPoint + ' ' + 'баллов из 100'
console.log(resultOfElizar)

let resultOfExam = 'Экзамендин орточо баллы:  87.75 балл"'
console.log(resultOfExam)



// SECOND ASSIGMENT

let numberX = 9
let numberY = 1
let result = numberX * numberY;
console.log(result);

let numberX2 = 9
let numberY2 = 2
let result2 = numberX2 * numberY2;
console.log(result2);

let numberX3 = 9
let numberY3 = 3
let result3 = numberX3 * numberY3;
console.log(result3);

let numberX4 = 9
let numberY4 = 4
let result4 = numberX4 * numberY4;
console.log(result4);

let numberX5 = 9
let numberY5 = 5
let result5 = numberX5 * numberY5;
console.log(result5);

let numberX6 = 9
let numberY6 = 6
let result6 = numberX6 * numberY6;
console.log(result6);

let numberX7 = 9
let numberY7 = 7
let result7 = numberX7 * numberY7;
console.log(result7);

let numberX8 = 9
let numberY8 = 8
let result8 = numberX8 * numberY8;
console.log(result8);

let numberX9 = 9
let numberY9 = 9
let result9 = numberX9 * numberY9;
console.log(result9);

let numberX10 = 9
let numberY10 = 10
let result10 = numberX10 * numberY10;
console.log(result10);



//  THIRD ASSIGMENT

alert("Вы успешно зарегистрировались!")

const confirmTrueResult = confirm("При перезагрузке сайта, введённые данные на форме будут очищены, Вы уверены что хотите перезагрузить?")

console.log(confirmTrueResult)

const promtName = prompt("Введите ваше имя")
console.log(promtName)