//ОТКРОЙТЕ ПО ОДНОЙ ЗАДАЧЕ АГАЙ.
// 1) ЗАДАЧА

// let number = 10
// if (number === 10) {
//     console.log('Туура')
// }else {
//     console.log('Туура эмес')
// }

// 2) ЗАДАЧА

// let entrance = 65
// if (entrance > 0 && entrance <= 20) {
// entrance = 1
// }else if (entrance > 21 && entrance <= 48) {
//     entrance = 2
// }else if (entrance > 49 && entrance <= 90) {
//     entrance = 3
// }else {
//     entrance = 'Error'
// }
// console.log(entrance)

// 3) ЗАДАЧА

// let number = 3
// if (number > 0 && number <= 5) {
//     console.log('true')
// }else {
//     console.log('false')
// }

// 4) ЗАДАЧА

// let a = 6
// let b = 13
// if (a > 2 && a <= 11 && b >= 6 && b < 14) {
//     console.log('Верно')
// }else {
//     console.log('Неверно')
// }

// 6) ЗАДАЧА

// let exam = +prompt('Программа берилген баллдар!5 Балдуу система!')
// if (exam > 0 && exam <= 49) {
//     exam = 2
// }else if (exam > 50 && exam <= 70) {
//     exam = 3
// }else if (exam > 71 && exam <= 85){
//     exam = 4
// }else if (exam > 86 && exam <= 100) {
//     exam = 5
// }else {
//     exam = 0
// }
// console.log(exam)

// 5) ЗАДАЧА

// let kamen = 'kamen';
// let nojnisa = 'nojnisa';
// let bumaga = 'bumaga';

// let playrOne = 'bumaga';
// let playrSecond = 'nojnisa';

// if (playrOne === kamen && playrSecond === nojnisa) {
//   console.log('playrOne Won');
// } else if (playrOne === kamen && playrSecond === bumaga) {
//   console.log('playrSecond Won');
// } else if (playrOne === kamen && playrSecond === kamen) {
//   console.log('Draw');
// } else if (playrOne === nojnisa && playrSecond === kamen) {
//   console.log('playrSecond Won');
// } else if (playrOne === nojnisa && playrSecond === nojnisa) {
//   console.log('Draw');
// } else if (playrOne === nojnisa && playrSecond === bumaga) {
//   console.log('playrOne Won');
// } else if (playrOne === bumaga && playrSecond === kamen) {
//   console.log('playrOne Won');
// } else if (playrOne === bumaga && playrSecond === nojnisa) {
//   console.log('playrSecond Won');
// } else if (playrOne === bumaga && playrSecond === bumaga) {
//   console.log('Draw');
// } else {
//   console.log('write one of the values:1)kamen 2)nojnisa 3)bumaga');
// }
